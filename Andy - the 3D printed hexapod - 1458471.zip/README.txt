Andy - the 3D printed hexapod by Sn00zerman on Thingiverse: https://www.thingiverse.com/thing:1458471

Summary:
The Andy hexapod is loosely based on the Phoenix hexapod from lynxmotion.See a movie of Andy - the hexapod, in action:https://youtu.be/f40JUxppfhM